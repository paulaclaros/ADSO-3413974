---
name: SENA Asistencia Inteligente
colors:
  surface: '#f7f9ff'
  surface-dim: '#d7dae0'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4fa'
  surface-container: '#ebeef4'
  surface-container-high: '#e5e8ee'
  surface-container-highest: '#dfe3e8'
  on-surface: '#181c20'
  on-surface-variant: '#3f4a38'
  inverse-surface: '#2d3135'
  inverse-on-surface: '#eef1f7'
  outline: '#6f7b66'
  outline-variant: '#becbb3'
  surface-tint: '#226d00'
  primary: '#226d00'
  on-primary: '#ffffff'
  primary-container: '#39a900'
  on-primary-container: '#0c3400'
  inverse-primary: '#6fdf43'
  secondary: '#006b5e'
  on-secondary: '#ffffff'
  secondary-container: '#9cefde'
  on-secondary-container: '#0b6f62'
  tertiary: '#b40e73'
  on-tertiary: '#ffffff'
  tertiary-container: '#fa52aa'
  on-tertiary-container: '#5b0037'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#8afd5d'
  primary-fixed-dim: '#6fdf43'
  on-primary-fixed: '#052100'
  on-primary-fixed-variant: '#185200'
  secondary-fixed: '#9ff2e1'
  secondary-fixed-dim: '#83d5c5'
  on-secondary-fixed: '#00201b'
  on-secondary-fixed-variant: '#005046'
  tertiary-fixed: '#ffd8e6'
  tertiary-fixed-dim: '#ffb0d0'
  on-tertiary-fixed: '#3d0024'
  on-tertiary-fixed-variant: '#8c0057'
  background: '#f7f9ff'
  on-background: '#181c20'
  surface-variant: '#dfe3e8'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 57px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.25px
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: 0px
  headline-md:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: 0px
  title-lg:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0.15px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.5px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.25px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.1px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.5px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  container-margin: 24px
  gutter: 16px
---

## Brand & Style
The brand personality for this design system is authoritative yet accessible, reflecting its role as a modern educational utility. It balances the institutional heritage of SENA with a forward-thinking, clean SaaS aesthetic. The UI is designed to evoke a sense of organized efficiency and reliability, ensuring that attendance management feels effortless rather than administrative.

The design follows **Material Design 3 (MD3)** principles, utilizing its systematic approach to color and containment. The style is professional and clinical, with a focus on high legibility and a reduced cognitive load through generous whitespace and a purposeful lack of visual clutter.

## Colors
The color palette is anchored by **SENA Institutional Green**, used strategically for primary actions and brand presence. The interface relies heavily on a "white-label" SaaS aesthetic, using pure white for the base background and light gray for surface containers to create subtle depth.

- **Primary**: Used for FABs, primary buttons, and active states.
- **Surface**: Used for cards and side navigation backgrounds to distinguish them from the main workspace.
- **Text**: Dark gray (#202124) is used for high-contrast headers, while medium gray (#5F6368) handles body text and labels to reduce eye strain.
- **States**: Use a 12% opacity overlay of the primary color for hover states on light surfaces.

## Typography
This design system utilizes **Inter** for all roles to achieve a modern, systematic feel. The type hierarchy follows MD3 scales, emphasizing clarity in data-dense environments. 

Headlines are set with slightly tighter letter spacing and higher weights to provide strong visual anchors. Body text maintains a generous line height (1.5x) to ensure legibility when reading long lists of names or attendance records. All labels use a medium weight to distinguish them clearly from interactive body text.

## Layout & Spacing
The layout follows a **fluid grid system** with a 12-column structure for desktop and an 8-column structure for tablets. A 8px base unit (linear scale) governs all spacing decisions to ensure mathematical harmony.

- **Margins**: 24px on desktop to allow the content to breathe.
- **Gutters**: Fixed 16px gutters between grid items.
- **Padding**: Large components like cards use 24px (lg) internal padding, while tighter elements like list items use 12px vertical and 16px horizontal padding.
- **Alignment**: All text and icons are left-aligned to follow the standard F-pattern of scanning, except for numerical data in tables which is right-aligned.

## Elevation & Depth
Depth is communicated through **Tonal Layers** supplemented by **Ambient Shadows**. This design system avoids heavy shadows, opting for "soft" elevation to maintain the clean SaaS aesthetic.

- **Level 0 (Flat)**: Standard background surface.
- **Level 1 (Raised)**: Cards and navigation bars. Use a very soft shadow: `0px 1px 3px rgba(0,0,0,0.05), 0px 1px 2px rgba(0,0,0,0.1)`.
- **Level 2 (Active/Hover)**: Elevated cards or dropdowns. `0px 4px 6px -1px rgba(0,0,0,0.1), 0px 2px 4px -1px rgba(0,0,0,0.06)`.
- **Modals**: High elevation with a 40% opacity black backdrop blur (8px) to focus the user's attention.

## Shapes
In alignment with Material Design 3 and the user's request, the shape language is distinctly **rounded**. 

- **Small Components**: Buttons and Input fields use a 12px radius.
- **Medium Components**: Cards and Modals use a 16px radius.
- **Large Components**: Navigation drawers and large containers use 24px radius on inner corners.
- **Full**: Chips and Search bars use a fully rounded (pill) shape to distinguish them from actionable containers.

## Components
- **Buttons**: Primary buttons are solid Institutional Green with white text and 12px corner radius. Secondary buttons are outlined in Light Gray with Green text.
- **Cards**: Use white backgrounds, 16px rounded corners, and Level 1 elevation. No borders are required unless placed on a white background, in which case a 1px Light Gray outline is used.
- **Input Fields**: Outlined style with a 12px radius. The label should float on the border when active (MD3 style).
- **Chips**: Used for attendance status (e.g., "Present", "Absent", "Excused"). Soft background tints based on status colors with dark text.
- **Lists**: Clean, borderless rows with 16px horizontal padding. High-contrast text for names and secondary text for ID numbers.
- **Checkboxes**: Use the primary green for the checked state. 4px rounded corners on the box itself.
- **Data Tables**: Minimalist approach with no vertical lines. Horizontal dividers should be 1px Light Gray. Headers are uppercase `label-md` with medium weight.